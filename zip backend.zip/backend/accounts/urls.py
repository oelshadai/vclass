from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import (
    CustomTokenObtainPairView,
    RegisterView,
    UserProfileView,
    ChangePasswordView,
    UserListView,
    CreateTeacherView,
    RegisterSchoolView,
    LogoutView,
)
from .password_views import forgot_password, reset_password_admin
from students.auth_views import student_login

# Student-aware profile view
class StudentAwareProfileView(UserProfileView):
    """Profile view that handles both regular users and students"""
    def get_object(self):
        user = self.request.user
        # If user is a student, redirect to student dashboard endpoint
        if hasattr(user, 'role') and user.role == 'STUDENT':
            from rest_framework.response import Response
            from rest_framework import status
            return Response(
                {'detail': 'Students should use /api/students/auth/dashboard/ endpoint'}, 
                status=status.HTTP_302_FOUND
            )
        return user

urlpatterns = [
    path('login/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('student-login/', student_login, name='student_login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('register/', RegisterView.as_view(), name='register'),
    path('register-school/', RegisterSchoolView.as_view(), name='register_school'),
    path('profile/', StudentAwareProfileView.as_view(), name='profile'),
    path('change-password/', ChangePasswordView.as_view(), name='change_password'),
    path('users/', UserListView.as_view(), name='user_list'),
    path('teachers/create/', CreateTeacherView.as_view(), name='create_teacher'),
    path('forgot-password/', forgot_password, name='forgot_password'),
    path('reset-password/', reset_password_admin, name='reset_password_admin'),
]
