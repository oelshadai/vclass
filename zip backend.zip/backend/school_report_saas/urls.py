from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from students.portal_views import student_subjects, student_announcements
from students.auth_views import student_dashboard
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def announcements_list(request):
    """Get announcements for students"""
    try:
        from notifications.models import Notification
        notifications = Notification.objects.filter(
            user=request.user,
            type__in=['announcement', 'info', 'warning']
        ).order_by('-created_at')[:10]
        
        announcements = [{
            'id': notif.id,
            'title': notif.title,
            'content': notif.message,
            'created_at': notif.created_at.isoformat(),
            'priority': 'high' if notif.type == 'error' else 'medium',
            'read': notif.read
        } for notif in notifications]
        
        return Response(announcements)
    except Exception as e:
        return Response([], status=200)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/auth/', include('accounts.urls')),
    path('api/schools/', include('schools.urls')),
    path('api/students/', include('students.urls')),
    path('api/teachers/', include('teachers.urls')),
    path('api/scores/', include('scores.urls')),
    path('api/reports/', include('reports.urls')),
    path('api/assignments/', include('assignments.urls')),
    path('api/subscriptions/', include('subscriptions.urls')),
    path('api/notifications/', include('notifications.urls')),
    
    # Student portal API endpoints - ensure these return JSON
    path('api/classes/<int:class_id>/subjects/', student_subjects, name='class_subjects'),
    path('api/classes/<int:class_id>/announcements/', student_announcements, name='class_announcements'),
    path('api/announcements/student/', student_announcements, name='student_announcements'),
    path('api/announcements/', announcements_list, name='announcements_list'),
    path('api/student/dashboard/', student_dashboard, name='student_dashboard_main'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)