from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import get_user_model
from .models import Student
from .serializers import StudentSerializer, StudentAssignmentSerializer
from assignments.models import Assignment, StudentAssignment

@api_view(['POST'])
@permission_classes([AllowAny])
def student_login(request):
    """Student login endpoint"""
    try:
        student_id = request.data.get('student_id') or request.data.get('username')
        password = request.data.get('password')
        
        if not student_id or not password:
            return Response({'detail': 'Student ID and password are required'}, status=400)
        
        try:
            student = Student.objects.select_related('user', 'current_class', 'school').get(student_id=student_id)
        except Student.DoesNotExist:
            return Response({'detail': 'Invalid student ID or password'}, status=401)
        
        # Create user if doesn't exist
        if not student.user:
            from django.contrib.auth import get_user_model
            User = get_user_model()
            
            school_domain = student.school.name.lower().replace(' ', '').replace('-', '') if student.school else 'school'
            email = f"std_{student.student_id}@{school_domain}.edu"
            
            try:
                user = User.objects.create_user(
                    email=email,
                    password=password,
                    first_name=student.first_name,
                    last_name=student.last_name
                )
                user.role = 'STUDENT'
                if hasattr(user, 'school') and student.school:
                    user.school = student.school
                user.save()
                
                student.user = user
                student.password = password
                student.save(update_fields=['user', 'password'])
            except Exception as user_error:
                return Response({'detail': f'Failed to create user account: {str(user_error)}'}, status=500)
        
        # Ensure user has correct role
        if student.user.role != 'STUDENT':
            student.user.role = 'STUDENT'
            student.user.save(update_fields=['role'])
        
        # Verify password
        password_valid = False
        if student.password and student.password == password:
            password_valid = True
        elif student.user.check_password(password):
            password_valid = True
            # Update plain text password for consistency
            student.password = password
            student.save(update_fields=['password'])
        
        if not password_valid:
            return Response({'detail': 'Invalid student ID or password'}, status=401)
        
        # Generate tokens
        refresh = RefreshToken.for_user(student.user)
        
        return Response({
            'access': str(refresh.access_token),
            'refresh': str(refresh),
            'student': {
                'id': student.id,
                'name': student.get_full_name(),
                'student_id': student.student_id,
                'first_name': student.first_name,
                'last_name': student.last_name,
                'class': student.current_class.level if student.current_class else 'No Class',
                'class_id': student.current_class.id if student.current_class else None,
                'role': 'STUDENT',
                'email': student.user.email
            }
        })
        
    except Exception as e:
        import traceback
        print(f"Student login error: {str(e)}")
        print(traceback.format_exc())
        return Response({'detail': f'Login system error: {str(e)}'}, status=500)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def student_dashboard(request):
    """Get student dashboard data"""
    try:
        student = Student.objects.select_related('user', 'current_class', 'school').get(user=request.user)
    except Student.DoesNotExist:
        return Response({'detail': 'Student profile not found'}, status=404)
    
    try:
        # Get published assignments for student's class
        published_assignments = Assignment.objects.filter(
            class_instance=student.current_class,
            status='PUBLISHED'
        ).select_related('class_subject__subject') if student.current_class else Assignment.objects.none()
        
        # Create StudentAssignment records for new assignments
        created_count = 0
        for assignment in published_assignments:
            try:
                student_assignment, created = StudentAssignment.objects.get_or_create(
                    assignment=assignment,
                    student=student,
                    defaults={'status': 'NOT_STARTED'}
                )
                if created:
                    created_count += 1
            except Exception as e:
                print(f"Error creating student assignment: {e}")
                continue
        
        # Get student assignments
        assignments = StudentAssignment.objects.filter(
            student=student,
            assignment__status='PUBLISHED'
        ).select_related('assignment', 'assignment__class_subject__subject')
        
        # Get classmates
        classmates = []
        if student.current_class:
            try:
                classmates_qs = Student.objects.filter(
                    current_class=student.current_class
                ).exclude(id=student.id).select_related('user')[:10]
                
                classmates = [{
                    'id': classmate.id,
                    'name': classmate.get_full_name(),
                    'avatar': None,
                    'status': 'offline',
                    'last_seen': classmate.user.last_login.isoformat() if classmate.user and classmate.user.last_login else None
                } for classmate in classmates_qs]
            except Exception as e:
                print(f"Error fetching classmates: {e}")
                classmates = []
        
        # Get announcements (notifications)
        announcements = []
        try:
            from notifications.models import Notification
            notifications_qs = Notification.objects.filter(
                user=request.user,
                read=False
            ).order_by('-created_at')[:10]
            
            announcements = [{
                'id': notif.id,
                'title': notif.title,
                'content': notif.message,
                'created_at': notif.created_at.isoformat(),
                'priority': 'high' if notif.type == 'error' else 'medium',
                'read': notif.read
            } for notif in notifications_qs]
        except Exception as e:
            print(f"Error fetching notifications: {e}")
            announcements = []
        
        # Get reports
        reports = []
        try:
            from reports.models import ReportCard
            reports_qs = ReportCard.objects.filter(
                student=student,
                status__in=['GENERATED', 'PUBLISHED']
            ).order_by('-created_at')[:10]
            
            reports = [{
                'id': report.id,
                'title': f'{report.term} Report Card',
                'term': str(report.term),
                'date': report.created_at.isoformat(),
                'type': 'academic',
                'status': 'available'
            } for report in reports_qs]
        except Exception as e:
            print(f"Error fetching reports: {e}")
            reports = []
        
        # Get virtual sessions
        virtual_sessions = []
        try:
            from schools.models import VirtualSession
            sessions = VirtualSession.objects.filter(
                class_assigned=student.current_class,
                status__in=['SCHEDULED', 'LIVE']
            ).order_by('scheduled_time')[:5] if student.current_class else []
            
            virtual_sessions = [{
                'id': session.id,
                'title': session.title,
                'scheduled_time': session.scheduled_time.isoformat() if session.scheduled_time else None,
                'status': session.status,
                'duration': session.duration
            } for session in sessions]
        except Exception as e:
            print(f"Error fetching virtual sessions: {e}")
            virtual_sessions = []
        
        # Calculate stats
        total_assignments = assignments.count()
        completed = assignments.filter(status='SUBMITTED').count()
        graded = assignments.filter(status='GRADED').count()
        pending = assignments.filter(status__in=['NOT_STARTED', 'IN_PROGRESS']).count()
        
        response_data = {
            'student': {
                'id': student.id,
                'name': student.get_full_name(),
                'first_name': student.first_name,
                'last_name': student.last_name,
                'student_id': student.student_id,
                'class': student.current_class.level if student.current_class else 'No Class',
                'class_id': student.current_class.id if student.current_class else None,
                'email': student.user.email if student.user else None,
                'role': 'STUDENT'
            },
            'assignments': StudentAssignmentSerializer(assignments, many=True).data,
            'classmates': classmates,
            'announcements': announcements,
            'reports': reports,
            'virtual_sessions': virtual_sessions,
            'stats': {
                'total_assignments': total_assignments,
                'completed': completed,
                'pending': pending,
                'graded': graded
            }
        }
        
        return Response(response_data)
    
    except Exception as e:
        import traceback
        print(f"Student dashboard error: {str(e)}")
        print(traceback.format_exc())
        
        # Return minimal data instead of 500 error
        return Response({
            'student': {
                'id': student.id,
                'name': student.get_full_name(),
                'first_name': student.first_name,
                'last_name': student.last_name,
                'student_id': student.student_id,
                'class': student.current_class.level if student.current_class else 'No Class',
                'class_id': student.current_class.id if student.current_class else None,
                'email': student.user.email if student.user else None,
                'role': 'STUDENT'
            },
            'assignments': [],
            'classmates': [],
            'announcements': [],
            'reports': [],
            'virtual_sessions': [],
            'stats': {
                'total_assignments': 0,
                'completed': 0,
                'pending': 0,
                'graded': 0
            }
        })

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def student_logout(request):
    """Student logout endpoint"""
    try:
        refresh_token = request.data.get('refresh')
        if refresh_token:
            token = RefreshToken(refresh_token)
            token.blacklist()
        return Response({'detail': 'Successfully logged out'}, status=200)
    except Exception as e:
        return Response({'detail': 'Logout failed'}, status=400)