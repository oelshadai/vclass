from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .models import Student
from .serializers import StudentAssignmentSerializer
from schools.models import Class, ClassSubject
from schools.serializers import SubjectSerializer
from notifications.models import Notification
from assignments.models import Assignment, StudentAssignment

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def student_profile(request):
    """Get student profile data"""
    try:
        student = Student.objects.get(user=request.user)
        return Response({
            'id': student.id,
            'student_id': student.student_id,
            'name': student.get_full_name(),
            'first_name': student.first_name,
            'last_name': student.last_name,
            'email': request.user.email,
            'class': student.current_class.level if student.current_class else None,
            'class_id': student.current_class.id if student.current_class else None,
            'role': 'STUDENT'
        })
    except Student.DoesNotExist:
        return Response({'detail': 'Student profile not found'}, status=404)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def student_classes(request):
    """Get student's classes"""
    try:
        student = Student.objects.get(user=request.user)
        if student.current_class:
            return Response([{
                'id': student.current_class.id,
                'name': str(student.current_class),
                'level': student.current_class.level,
                'section': student.current_class.section or '',
                'class_teacher': student.current_class.class_teacher.get_full_name() if student.current_class.class_teacher else None
            }])
        return Response([])
    except Student.DoesNotExist:
        return Response({'detail': 'Student profile not found'}, status=404)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def student_subjects(request, class_id):
    """Get subjects for a specific class"""
    try:
        student = Student.objects.get(user=request.user)
        class_instance = get_object_or_404(Class, id=class_id)
        
        if student.current_class != class_instance:
            return Response({'detail': 'Access denied to this class'}, status=403)
        
        class_subjects = ClassSubject.objects.filter(class_instance=class_instance).select_related('subject', 'teacher')
        
        subjects = []
        for cs in class_subjects:
            subjects.append({
                'id': cs.subject.id,
                'name': cs.subject.name,
                'code': cs.subject.code,
                'teacher': cs.teacher.get_full_name() if cs.teacher else 'No Teacher Assigned',
                'category': cs.subject.category
            })
        
        return Response(subjects)
    except Student.DoesNotExist:
        return Response({'detail': 'Student profile not found'}, status=404)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def student_announcements(request, class_id=None):
    """Get announcements for student"""
    try:
        student = Student.objects.get(user=request.user)
        class_id = class_id or request.GET.get('class_id')
        
        notifications = Notification.objects.filter(
            user=request.user,
            read=False
        ).order_by('-created_at')[:10]
        
        announcements = []
        for notif in notifications:
            announcements.append({
                'id': notif.id,
                'title': notif.title,
                'content': notif.message,
                'date': notif.created_at.isoformat(),
                'priority': 'high' if notif.type == 'error' else 'medium',
                'read': notif.read
            })
        
        return Response(announcements)
    except Student.DoesNotExist:
        return Response({'detail': 'Student profile not found'}, status=404)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def student_assignments_list(request):
    """Get assignments for student"""
    try:
        student = Student.objects.select_related('current_class').get(user=request.user)
        
        # Get published assignments for student's class
        published_assignments = Assignment.objects.filter(
            class_instance=student.current_class,
            status='PUBLISHED'
        ).select_related('class_subject__subject') if student.current_class else Assignment.objects.none()
        
        # Create StudentAssignment records for new assignments
        for assignment in published_assignments:
            StudentAssignment.objects.get_or_create(
                assignment=assignment,
                student=student,
                defaults={'status': 'NOT_STARTED'}
            )
        
        # Get student assignments
        assignments = StudentAssignment.objects.filter(
            student=student,
            assignment__status='PUBLISHED'
        ).select_related('assignment', 'assignment__class_subject__subject')
        
        return Response(StudentAssignmentSerializer(assignments, many=True).data)
    except Student.DoesNotExist:
        return Response({'detail': 'Student profile not found'}, status=404)
    except Exception as e:
        return Response([], status=200)  # Return empty list instead of error