from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import StudentViewSet, AttendanceViewSet, BehaviourViewSet, StudentPromotionViewSet, DailyAttendanceViewSet, create_behaviour_record
from .auth_views import student_login, student_dashboard, student_logout
from .portal_views import student_classes, student_subjects, student_announcements, student_profile, student_assignments_list
from accounts.password_views import change_password

router = DefaultRouter()
router.register(r'', StudentViewSet, basename='student')
router.register(r'attendance', DailyAttendanceViewSet, basename='attendance')
router.register(r'term-attendance', AttendanceViewSet, basename='term-attendance')
router.register(r'behaviour', BehaviourViewSet, basename='behaviour')
router.register(r'promotions', StudentPromotionViewSet, basename='promotion')

urlpatterns = [
    # Student Authentication
    path('auth/login/', student_login, name='student_login'),
    path('auth/logout/', student_logout, name='student_logout'),
    path('auth/dashboard/', student_dashboard, name='student_dashboard'),
    path('auth/change-password/', change_password, name='student_change_password'),
    
    # Student Profile
    path('profile/', student_profile, name='student_profile'),
    
    # Student Dashboard API (alternative endpoint)
    path('dashboard/', student_dashboard, name='student_dashboard_api'),
    
    # Student Portal APIs
    path('my-classes/', student_classes, name='student_classes'),
    path('assignments/', student_assignments_list, name='student_assignments'),
    
    # Behaviour
    path('behaviour/create/', create_behaviour_record, name='create_behaviour'),
] + router.urls