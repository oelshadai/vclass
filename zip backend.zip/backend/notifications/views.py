from rest_framework import viewsets, status
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Notification
from .serializers import NotificationSerializer

class NotificationViewSet(viewsets.ModelViewSet):
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user)
    
    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
    
    @action(detail=False, methods=['post'])
    def mark_all_read(self, request):
        self.get_queryset().update(read=True)
        return Response({'status': 'success'})

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def announcements_list(request):
    """Get announcements for students"""
    try:
        notifications = Notification.objects.filter(
            user=request.user,
            type__in=['announcement', 'info', 'warning']
        ).order_by('-created_at')[:10]
        
        announcements = [{
            'id': notif.id,
            'title': notif.title,
            'content': notif.message,
            'created_at': notif.created_at.isoformat(),
            'priority': 'high' if notif.type == 'error' else 'medium',
            'read': notif.read
        } for notif in notifications]
        
        return Response(announcements)
    except Exception as e:
        return Response([], status=200)  # Return empty list instead of error